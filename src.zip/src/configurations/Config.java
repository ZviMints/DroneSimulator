package configurations;

public class Config {
	public static  String root = "./Maps/";

}
