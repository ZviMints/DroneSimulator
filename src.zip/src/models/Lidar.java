package models;

import configurations.WorldParams;
import map.Tools;

import java.awt.*;
import java.util.Random;

public class Lidar {
    public Drone drone;
    public double degrees;
    public double distance = 0;

    public Lidar(Drone drone, double degrees) {
        this.drone = drone;
        this.degrees = degrees;
    }

    public double getMaxDistanceInCM() {
        Point actualPointToShoot = drone.getPointOnMap();
        double rotation = drone.getRotation() + degrees;
        double maxDistance = 1;
        for(double distanceInCM = 1; distanceInCM<= WorldParams.lidarLimit; distanceInCM++) {
            Point p = Tools.getPointByDistance(actualPointToShoot, rotation, distanceInCM);
            if (drone.map.isNotMap((int) p.x, (int) p.y)) {
                maxDistance = distanceInCM;
                break;
            }
        }
        return maxDistance;
    }

    public double getSimulationDistance() {
        Random ran = new Random();
        double distanceInCM;
        if (ran.nextFloat() <= 0.05f) { // 5% of the time, not getting an answer
            distanceInCM = 0;
        } else {
            distanceInCM = getMaxDistanceInCM();
            distanceInCM += ran.nextInt(WorldParams.lidarNoise * 2) - WorldParams.lidarNoise; // +- 5 CM to the final calc
        }

        this.distance = distanceInCM; // store it for instance get
        return distanceInCM;
    }


    public void paint(Graphics g) {
        Point actualPointToShoot = drone.getPointOnMap();
        double fromRotation = drone.getRotation() + degrees;
        Point to = Tools.getPointByDistance(actualPointToShoot, fromRotation, this.distance);
        g.drawLine((int) actualPointToShoot.x, (int) actualPointToShoot.y, (int) to.x, (int) to.y);
    }


}
