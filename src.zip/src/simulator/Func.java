package simulator;

public interface Func {
	void method();
}
