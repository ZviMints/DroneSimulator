package algorithms;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

import cpu.CPU;
import models.Drone;
import simulator.Func;
import models.Lidar;
import map.Map;
import map.Tools;
import configurations.WorldParams;
import models.Point;
import simulator.SimulationWindow;

public class ZviAndGalAlgorithm implements BaseAlgo {

    int map_size_width;
    int map_size_height;

    public mapState statesMap[][];
    public Drone drone;

    ArrayList<Point> points;

    int isRotating;
    ArrayList<Double> degrees_left;
    ArrayList<Func> degrees_left_func;

    CPU cpu;

    boolean justInitialized = true;
    public boolean risky = false;
    public boolean tried_to_escape = false;
    public double risky_dis = 0;
    public int max_angle_risky = 10;

    boolean is_lidars_max = false;
    double max_distance_between_points = 100;
    Point currentPoint;
    double lastGyroRotation = 0;

    // =========================== Constructor =========================== //
    public ZviAndGalAlgorithm(Map map) {
        System.out.println("Initialize " + getAlgoName() + " Algorithm");

        degrees_left = new ArrayList<>();
        degrees_left_func = new ArrayList<>();
        points = new ArrayList<>();

        // Adding Drone And Lidars
        drone = new Drone(map);
        drone.addLidar(0);
        drone.addLidar(90);
        drone.addLidar(-90);
        map_size_width = map.getWidth();
        map_size_height = map.getHeight();

        // Init map
        this.statesMap = new mapState[map_size_height][map_size_width];
        for (int i = 0; i < map_size_height; i++) {
            for (int j = 0; j < map_size_width; j++) {
                if (map.isNotMap(i, j)) this.statesMap[i][j] = mapState.out;
                else this.statesMap[i][j] = mapState.unexplored;
            }
        }

        isRotating = 0;
        cpu = new CPU(200, "Auto_AI");
        cpu.addFunction(this::update);
    }

    // ===========================  Functions =============================== //
    enum SpeedStates {speedUp, speedDown, remain}

    public SpeedStates speed_state = SpeedStates.remain;


    public void paintBlindMap(Graphics g) {
        Color c = g.getColor();
        for (int i = 0; i < map_size_height; i++) {
            for (int j = 0; j < map_size_width; j++) {
                if (statesMap[i][j] != mapState.unexplored) {
                    if (statesMap[i][j] == mapState.blocked) {
                        g.setColor(Color.RED);
                    } else if (statesMap[i][j] == mapState.explored) {
                        g.setColor(Color.YELLOW);
                    } else if (statesMap[i][j] == mapState.visited) {
                        g.setColor(Color.BLUE);
                    } else if (statesMap[i][j] == mapState.out) {
                        g.setColor(Color.BLACK);
                    }
                    g.drawLine(i, j, i, j);
                }
            }
        }
        g.setColor(c);
    }


    public void paintPoints(Graphics g) {
        for (int i = 0; i < points.size(); i++) {
            Point p = points.get(i);
            g.drawOval((int) p.x + (int) drone.drone_start_point.x - 10, (int) p.y + (int) drone.drone_start_point.y - 10, 20, 20);
        }
    }

    public void update(int deltaTime) {
        updateVisited();
        updateMapByLidars();
        Think();

        if (isRotating != 0) updateRotating(deltaTime);

        if (speed_state == SpeedStates.speedUp) {
            drone.speedUp(deltaTime * 7);
            speed_state = SpeedStates.remain;
        } else if (speed_state == SpeedStates.speedDown) {
            drone.slowDown(deltaTime * 7);
            speed_state = SpeedStates.remain;
        }
    }

    public void spinBy(double degrees, boolean isFirst, Func func) {
        lastGyroRotation = drone.getGyroRotation();
        if (isFirst) {
            degrees_left.add(0, degrees);
            degrees_left_func.add(0, func);
        } else {
            degrees_left.add(degrees);
            degrees_left_func.add(func);
        }
        isRotating = 1;
    }

    public void spinBy(double degrees) {
        lastGyroRotation = drone.getGyroRotation();
        degrees_left.add(degrees);
        degrees_left_func.add(null);
        isRotating = 1;
    }

    public void updateRotating(int deltaTime) {
        if (degrees_left.size() != 0) {

            double degrees_left_to_rotate = degrees_left.get(0);
            boolean isLeft = true;
            if (degrees_left_to_rotate > 0) {
                isLeft = false;
            }

            double curr = drone.getGyroRotation();
            double just_rotated = 0;

            if (isLeft) {
                just_rotated = curr - lastGyroRotation;
                if (just_rotated > 0) {
                    just_rotated = -(360 - just_rotated);
                }
            } else {
                just_rotated = curr - lastGyroRotation;
                if (just_rotated < 0) {
                    just_rotated = 360 + just_rotated;
                }
            }

            lastGyroRotation = curr;
            degrees_left_to_rotate -= just_rotated;
            degrees_left.remove(0);
            degrees_left.add(0, degrees_left_to_rotate);

            if ((isLeft && degrees_left_to_rotate >= 0) || (!isLeft && degrees_left_to_rotate <= 0)) {
                degrees_left.remove(0);

                Func func = degrees_left_func.get(0);
                if (func != null) {
                    func.method();
                }
                degrees_left_func.remove(0);


                if (degrees_left.size() == 0) {
                    isRotating = 0;
                }
                return;
            }

            int direction = (int) (degrees_left_to_rotate / Math.abs(degrees_left_to_rotate));
            drone.rotateLeft(deltaTime * direction);

        }
    }

    public void updateMapByLidars() {
        Point fromPoint = drone.getPointOnMap();
        for (int i = 0; i < drone.lidars.size(); i++) {
            Lidar lidar = drone.lidars.get(i);
            double rotation = drone.getGyroRotation() + lidar.degrees;
            for (int distanceInCM = 0; distanceInCM < lidar.distance; distanceInCM++) {
                Point p = Tools.getPointByDistance(fromPoint, rotation, distanceInCM);
                setPixel(p.x, p.y, mapState.explored);
            }

            if (lidar.distance > 0 && lidar.distance < WorldParams.lidarLimit - WorldParams.lidarNoise) {
                Point p = Tools.getPointByDistance(fromPoint, rotation, lidar.distance);
                setPixel(p.x, p.y, mapState.blocked);
            }
        }
    }

    public void updateVisited() {
        Point fromPoint = drone.getPointOnMap();
        setPixel(fromPoint.x, fromPoint.y, mapState.visited);

    }

    public void setPixel(double x, double y, mapState state) {
        int xi = (int) x;
        int yi = (int) y;

        if (state == mapState.visited) {
            statesMap[xi][yi] = state;
            return;
        }

        if (statesMap[xi][yi] == mapState.unexplored) {
            statesMap[xi][yi] = state;
        }
    }

    // =========================== Override Functions =============================== //
    @Override
    public void paint(Graphics g) {
        if (SimulationWindow.toogleRealMap) drone.map.paint(g);
        paintBlindMap(g);
        paintPoints(g);
        drone.paint(g);
    }

    @Override
    public String getAlgoName() {
        return "ZviAndGal Algorithm";
    }

    @Override
    public void speedUp() {
        speed_state = SpeedStates.speedUp;
    }

    @Override
    public void speedDown() {
        speed_state = SpeedStates.speedDown;
    }

    @Override
    public Drone getDrone() {
        return drone;
    }

    @Override
    public void play() {
        drone.play();
        cpu.play();
    }

    @Override
    public boolean getRiskyState() {
        return this.risky;
    }

    @Override
    public double getRiskyDistance() {
        return this.risky_dis;
    }

    // =========================== Main Method =============================== //
    public void Think() {
        if (SimulationWindow.toogleAI) {

            if (justInitialized) {
                Point dronePoint = drone.getOpticalSensorLocation();
                currentPoint = new Point(dronePoint);
                points.add(dronePoint);
                graph.addVertex(dronePoint);
                justInitialized = false;
            }

            Point dronePoint = drone.getOpticalSensorLocation();

            if (SimulationWindow.return_home) {
                System.out.println("[Drone] I Dont want return to home.");
                SimulationWindow.return_home = false;
            } else {
                if (Tools.getDistanceBetweenPoints(getLastPoint(), dronePoint) >= max_distance_between_points) {
                    points.add(dronePoint);
                    graph.addVertex(dronePoint);
                }
            }
            if(!tried_to_escape) {
                tried_to_escape = true;
                Lidar lidar1 = drone.lidars.get(1);
                double a = lidar1.distance;

                Lidar lidar2 = drone.lidars.get(2);
                double b = lidar2.distance;

                int spin_by = max_angle_risky;

                if(a > 270 && b > 270) {
                    is_lidars_max = true;
                    Point l1 = Tools.getPointByDistance(dronePoint, lidar1.degrees + drone.getGyroRotation(), lidar1.distance);
                    Point l2 = Tools.getPointByDistance(dronePoint, lidar2.degrees + drone.getGyroRotation(), lidar2.distance);
                    Point last_point = getAvgLastPoint();
                    double dis_to_lidar1 = Tools.getDistanceBetweenPoints(last_point,l1);
                    double dis_to_lidar2 = Tools.getDistanceBetweenPoints(last_point,l2);

                    if(SimulationWindow.return_home) {
                        if( Tools.getDistanceBetweenPoints(getLastPoint(), dronePoint) <  max_distance_between_points) {
                            removeLastPoint();
                        }
                    } else {
                        if( Tools.getDistanceBetweenPoints(getLastPoint(), dronePoint) >=  max_distance_between_points) {
                            points.add(dronePoint);
                            graph.addVertex(dronePoint);
                        }
                    }

                    spin_by = 90;
                    if(SimulationWindow.return_home) {
                        spin_by *= -1;
                    }


                    if(dis_to_lidar1 < dis_to_lidar2) {

                        spin_by *= (-1 );
                    }
                } else {
                    if(a < b ) {
                        spin_by *= (-1 );
                    }
                }

                spinBy(spin_by,true, () -> {
                    tried_to_escape = false;
                    risky = false;
                });
            }
        }
    }

    public Point getAvgLastPoint() {
        if (points.size() < 2) return currentPoint;
        else {
            Point p1 = points.get(points.size() - 1);
            Point p2 = points.get(points.size() - 2);
            return new Point((p1.x + p2.x) / 2, (p1.y + p2.y) / 2);
        }
    }

    public Point removeLastPoint() {
        if (points.isEmpty()) return currentPoint;
        else return points.remove(points.size() - 1);
    }

    public Point getLastPoint() {
        if (points.size() == 0) return currentPoint;
        Point p = points.get(points.size() - 1);
        return p;
    }

    public boolean checkOutOfBounds() {
        Point current = drone.getPointOnMap();
        if (statesMap[(int) current.x][(int) current.y] == mapState.out) {
            System.out.println("Went wayyyy to much!");
            return true;
        }
        return false;
    }
}

